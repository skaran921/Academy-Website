<!DOCTYPE html>
<htmL>
<title>
Sitemap - Abhyas Academy Ellenabad
</title>
  <meta name="author" content="skaran921,karan soni">
  <meta name="keyword" content="aaellenabad,Abhyas Academy Ellenabad,skaran921,Add New Student,sitemap">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<!------meta tag------>
<!----------------------Bootstrap Files--------------------------->
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="bootstrap/carousel.css" rel="stylesheet">
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/bootstrap.js"></script>
<!---------------------css Files------------------>
<link href="images/logo.jpg" rel="icon">
<link href="alertify/css/alertify.css" rel="stylesheet" id="alertifyCSS">
<link href="css/header.css" rel="stylesheet">
<link href="css/index.css" rel="stylesheet">
</head>
<body>
<!--------------------Header call here----------------->
<?php include 'header.php'; ?>
<div class="container-fluid"><!--------------------------------------container start here----------------------->
<div class="row"><!-----------------------------------row start here-------------------------------------->
<div class="col-sm-12"><!--------------------------------------col start here----------------------------->
<div class="panel panel-default"><!------------------------------Panel start here------------------------->
<div class="panel-heading" style="background-color:#744;color:white;"><!-----------------------------------heading start here------------------------->
<b>Sitemap</b>
</div><!--------------------------------------heading close here----------------------------------->
<div class="panel-body"><!-----------------------------------body start here------------------------------>
             <div class="row">
             <div class="col-sm-3">
                         <div class="list-group" style="">
  <a href="#" class="list-group-item-heading"><b><font color="red"><span class="glyphicon glyphicon-hand-right"></span> For All User's<span class="glyphicon glyphicon-hand-down"></span></font></b></a>
  <a href="index.php" class="list-group-item"><b><font color="green"><span class="glyphicon glyphicon-arrow-right"></span> Home</font></b></a>
  <a href="about.php" class="list-group-item"><b><font color="green"><span class="glyphicon glyphicon-arrow-right"></span> About us</font></b></a>
  <a href="contact.php" class="list-group-item"><b><font color="green"><span class="glyphicon glyphicon-arrow-right"></span> Contact us</font></b></a>
  <a href="form.php" class="list-group-item"><b><font color="green"><span class="glyphicon glyphicon-arrow-right"></span> Apply Online Admission</font></b></a>
  <a href="notification.php" class="list-group-item"><b><font color="green"><span class="glyphicon glyphicon-arrow-right"></span> View Notification</font></b></a>
  <a href="course.php" class="list-group-item"><b><font color="green"><span class="glyphicon glyphicon-arrow-right"></span> Know About All Course</font></b></a>
  <a href="corner.php" class="list-group-item"><b><font color="green"><span class="glyphicon glyphicon-arrow-right"></span> Student Corner</font></b></a>
  <a href="gallary.php" class="list-group-item"><b><font color="green"><span class="glyphicon glyphicon-arrow-right"></span> Image Gallary</font></b></a>
  </div><!----div close----->
  </div><!----col close----->
        
             <div class="col-sm-3">
                         <div class="list-group" style="">
  <a href="#" class="list-group-item-heading"><b><font color="indigo"><span class="glyphicon glyphicon-hand-right"></span> Only For Admin<span class="glyphicon glyphicon-hand-down"></span></font></b></a>
  <a href="dashboard.php" class="list-group-item"><b><font color="orange"><span class="glyphicon glyphicon-arrow-right"></span> Dashboard</font></b></a>
  <a href="shortnoti.php" class="list-group-item"><b><font color="orange"><span class="glyphicon glyphicon-arrow-right"></span> Add Short Notification</font></b></a>
  <a href="add student.php" class="list-group-item"><b><font color="orange"><span class="glyphicon glyphicon-arrow-right"></span> Add New Student</font></b></a>
  <a href="search student.php" class="list-group-item"><b><font color="orange"><span class="glyphicon glyphicon-arrow-right"></span> Search Student Record</font></b></a>
  <a href="update student.php" class="list-group-item"><b><font color="orange"><span class="glyphicon glyphicon-arrow-right"></span> Update a Existing Record</font></b></a>
  <a href="fee.php" class="list-group-item"><b><font color="orange"><span class="glyphicon glyphicon-arrow-right"></span> Fee Management</font></b></a>
  <a href="list.php" class="list-group-item"><b><font color="orange"><span class="glyphicon glyphicon-arrow-right"></span>Search Unique id</font></b></a>
  <a href="thought.php" class="list-group-item"><b><font color="orange"><span class="glyphicon glyphicon-arrow-right"></span>Add New Thought</font></b></a>
  <a href="addnoti.php" class="list-group-item"><b><font color="orange"><span class="glyphicon glyphicon-arrow-right"></span>Add New Notification</font></b></a>
  <a href="moniter.php" class="list-group-item"><b><font color="orange"><span class="glyphicon glyphicon-arrow-right"></span>Moniter Notification</font></b></a>
  Note:-  
  </div><!----div close----->
  </div><!----col close----->
        </div>
		
</div><!--------------------------------------body close here----------------------------------->
</div><!--------------------------------------body panel here----------------------------------->
</div><!--------------------------------------col close here----------------------------------->
</div><!--------------------------------------row close here----------------------------------->

<!--------------------Follow us call here-------------->
<?php include 'follow.php';?>
<!--------------------footer call here----------------->
<?php include 'footer.php' ?>
</div><!--------------------------------------container close here----------------------------------->
</body>
</html>