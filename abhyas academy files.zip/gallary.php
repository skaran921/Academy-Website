<!DOCTYPE html>
<htmL>
<title>
Gallary - Abhyas Academy Ellenabad
</title>
  <meta name="author" content="skaran921,karan soni">
  <meta name="keyword" content="aaellenabad,Abhyas Academy Ellenabad,skaran921,About us">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<!------meta tag------>
<!----------------------Bootstrap Files--------------------------->
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="bootstrap/carousel.css" rel="stylesheet">
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/bootstrap.js"></script>
<!---------------------css Files------------------>
<link href="images/logo.jpg" rel="icon">
<link href="alertify/css/alertify.css" rel="stylesheet" id="alertifyCSS">
<link href="css/header.css" rel="stylesheet">
<link href="css/index.css" rel="stylesheet">
</head>
<body>
<!--------------------Header call here----------------->
<?php include 'header.php'; ?>
<div class="panel panel-default">
<div class="panel-heading">
<b>Image Gallary</b>
</div><!--panel heading close here--->
<div class="panel-body">
<div class="row">
<div class="col-sm-2">
<img src="images/abhyas.jpg" alt="abhyas academy Ellenabad" class="img-fluid img-thumbnail" style="width:300px;">
</div><!---col 1 close here--->

<div class="col-sm-2">
<img src="images/abhyas1.jpg" alt="abhyas academy Ellenabad" class="img-fluid img-thumbnail" style="width:300px;">
</div><!---col 1 close here--->

<div class="col-sm-2">
<img src="images/abhyas2.jpg" alt="abhyas academy Ellenabad" class="img-fluid img-thumbnail" style="width:300px;">
</div><!---col 1 close here--->

<div class="col-sm-2">
<img src="images/abhyas3.jpg" alt="abhyas academy Ellenabad" class="img-fluid img-thumbnail" style="width:300px;">
</div><!---col 1 close here--->

<div class="col-sm-2">
<img src="images/abhyas0.jpeg" alt="abhyas academy Ellenabad" class="img-fluid img-thumbnail" style="width:300px;">
</div><!---col 1 close here--->

<div class="col-sm-2">
<img src="logo.jpg" alt="abhyas academylogo" class="img-fluid img-thumbnail" style="width:300px;">
</div><!---col 2 close here--->

</div><!---row close here--->

<div class="row">
<div class="col-sm-2">
<img src="images/HS-CIT.jpg" alt="HS-CIT" class="img-fluid img-thumbnail" style="width:150px;height:;">
</div><!---col 3 close here--->

<div class="col-sm-2">
<img src="images/Skill India.png" alt="Skill India" class="img-fluid img-thumbnail" style="width:150px;height:;">
</div><!---col 4 close here--->

<div class="col-sm-2">
<img src="images/modi.png" alt="modi" class="img-fluid img-thumbnail" style="width:300px;height:;">
</div><!---col 5 close here--->

<div class="col-sm-2">
<img src="images/NSDC.jpg" alt="NSDC" class="img-fluid img-thumbnail" style="width:300px;height:;">

<div class="col-sm-2">
<img src="images/PMKVY.jpg" alt="PMKVY" class="img-fluid img-thumbnail" style="width:300px;height:;">
</div><!---col 1 close here--->

</div><!---row close here--->
</div><!--- panel body close--->
</div><!--- panel close--->
<!--------------------Follow us call here-------------->
<?php include 'follow.php';?>
<!--------------------footer call here----------------->
<?php include 'footer.php' ?>
</body>
</html>
<script src="alertify/js/alertify.js"></script>
 