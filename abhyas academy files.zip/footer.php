<link href="css/footer.css" rel="stylesheet">
<div class="panel panel-primary">
   <div class="panel-heading">
      <b>About Developer</b>
   </div>
     <div class="panel-body" id="body">
	    <center><p>
		Designed And Developed By<a href="http://www.skaran.jimdo.com" title="skaran921"><img src="skaran921.png"  alt="skaran921" title="skaran921"></a> 
		<b>Karan Soni</b></p>
		<b>&copy2017 </b>
		<br>
		<mark><b style="color:red">Note:</b>
		<b>Please use Google Chrome or Opera For Best View of this website and any kind of problem or complaint you can also send us a message using this webisite from contact menu.
		<br>Your Feedback is very important for us..</b>  </mark>
		</center>
	 </div>
</div>