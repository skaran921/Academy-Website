function time(){
var A= new Date();
var x="<span class='glyphicon glyphicon-time'></span>";
document.getElementById("time").innerHTML=x+' '+A.toLocaleTimeString();
setTimeout(time,1000);}
window.onload=time;