<!DOCTYPE html>
<htmL>
<title>
About HSCIT Course
</title>
  <meta name="author" content="skaran921,karan soni">
  <meta name="keyword" content="aaellenabad,Abhyas Academy Ellenabad,skaran921,Add New Student">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<!------meta tag------>
<!----------------------Bootstrap Files--------------------------->
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="bootstrap/carousel.css" rel="stylesheet">
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/bootstrap.js"></script>
<!---------------------css Files------------------>
<link href="logo.jpg" rel="icon">
<link href="alertify/css/alertify.css" rel="stylesheet" id="alertifyCSS">
<link href="css/header.css" rel="stylesheet">
<link href="css/index.css" rel="stylesheet">
</head>
<body>
<!--------------------Header call here----------------->
<?php include 'header.php'; ?>
<input type="button" value="Dashboard" class="btn btn-danger" onclick="window.open('dashboard.php','_selef')">

<div class="panel panel-primary" style="margin-top:10px;">
<div class="panel-heading">
<b>About HS-CIT Course</b>
</div><!--- panel heading close here--->
<div class="panel-body">

      <center>
	  <h3 style="color:orange">
	  <u>Welcome to HS-CIT</u><br>
	  </h3>
	  </center>
	  <center>
	  <h1>
	  <font color="red"> <span class="glyphicon glyphicon-hand-down"></span> </font>
	  </h1>
	  </center>
	  

<p><b>HS-CIT is an Information Technology (IT) literacy course started by HKCL in the year 2014.</b> </p>
<b><u style="color:indigo;font-size:18px;">This Course Comprises Of :-</u></b><br>
<ol style="font-weight:bold;font-family:arial;">
<li><font color="red"> <span class="glyphicon glyphicon-hand-right"></span> </font>Reading and understanding a highly illustrated book</li>
<li><font color="red"> <span class="glyphicon glyphicon-hand-right"></span> </font>eLearning based self-learning sessions</li>
<li><font color="red"> <span class="glyphicon glyphicon-hand-right"></span> </font>Through HKCL's eLearning Revolution for All (ERA)</li>
<li><font color="red"> <span class="glyphicon glyphicon-hand-right"></span> </font>Providing hands-on practice sessions.</li>
<li><font color="red"> <span class="glyphicon glyphicon-hand-right"></span> </font>Learning facilitation by certified professionals</li>
<li><font color="red"> <span class="glyphicon glyphicon-hand-right"></span> </font>With academic interactions, assessments, and collaboration</li>

After completing this course, the learners will emerge as confident and versatile users of Information Technology.
</ol>
<b style="color:red"><span class="glyphicon glyphicon-asterisk"></span></b>
<b style="font-family:calbari;font-size:18px;color:slateblue">
Upon successfully completing the course, learners will be awarded the Haryana State - Certificate for Information Technology, jointly certified by Haryana Board of School Education, Bhiwani & Haryana Knowledge Corporation Limited, Panchkula.
</b><br>
<b style="color:green">
ONLINE ADMISSION FOR HS-CIT FILL A BASIC ONLINE FORM LINK ARE PROVIDED ABOVE  RIGHT SIDE OF TOP MENU OR <a href="form.php" title="Apply Online For Admission">CLICK HERE.</a> 
</b>

</div><!--- Panel body here--->
</div><!--- Panel close here--->

<!--------------------Follow us call here-------------->
<?php include 'follow.php';?>
<!--------------------footer call here----------------->
<?php include 'footer.php' ?>
</body>
</html>
<script src="alertify/js/alertify.js"></script>