<!DOCTYPE html>
<htmL>
<title>
Course - Abhyas Academy Ellenabad
</title>
  <meta name="author" content="skaran921,karan soni">
  <meta name="keyword" content="aaellenabad,Abhyas Academy Ellenabad,skaran921,About us">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<!------meta tag------>
<!----------------------Bootstrap Files--------------------------->
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="bootstrap/carousel.css" rel="stylesheet">
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/bootstrap.js"></script>
<!---------------------css Files------------------>
<link href="images/logo.jpg" rel="icon">
<link href="alertify/css/alertify.css" rel="stylesheet" id="alertifyCSS">
<link href="css/header.css" rel="stylesheet">
<link href="css/index.css" rel="stylesheet">
</head>
<body>
<!--------------------Header call here----------------->
<?php include 'header.php'; ?>
<div class="panel panel-default">
<div class="panel-heading">
<b>Course's Detail</b>
</div><!--panel heading close here--->
<div class="panel-body">
           <div class="row">
		   <div class="col-sm-3">
          <div class="panel panel-default">
          <div class="panel-heading" style="background-color:orange;color:white;">
          <b>HS-CIT</b>
          </div><!--panel heading close here--->
		  <div class="panel-body">
		  <center><b class="w3-jumbo">Rs.</b><b class="w3-xlarge"><sub>3350/-</sub></b></center>
		  <br>
		  <center><b>Feature's Of HS-CIT Course<b> 
		  <h1>
	       <font color="red"> <span class="glyphicon glyphicon-hand-down"></span> </font>
	      </h1>
		  </center>
		  <li>
		  <font color="green"> <span class="glyphicon glyphicon-hand-right"></span> </font>
		  <b><font color="orange">Duration:</font><font color="indigo">3 Month</font></b></li>
		  <hr>
		  <b><font color="orange">---------Syllabus----------</font></li></b>
		  <hr>
		  <b><li>
		  <font color="green"> <span class="glyphicon glyphicon-hand-right"></span> </font>
		  <font color="indigo">Basic Computer</font></b>
		  </li>
		  <b><li>
		  <font color="green"> <span class="glyphicon glyphicon-hand-right"></span> </font>
		  <font color="indigo">Typing Knowledge in Hindi& English</font>
		  </b></li>
		  <b><li>
		  <font color="green"> <span class="glyphicon glyphicon-hand-right"></span> </font>
		  <font color="indigo">internet Knowledge</font>
		  </b></li>
		  <b><li>
		  <font color="green"> <span class="glyphicon glyphicon-hand-right"></span> </font>
		  <font color="indigo">1 Hour Practical & Theory Class</font>
		  </b></li>
		  <font color="green"> <span class="glyphicon glyphicon-hand-right"></span> <b>For More Information <a href="hscit.php" title="HS-CIT Course">Click here</a></font>
		  </b>
		  
           </div><!--panel body close here--->
		   </div>
           </div><!--col 1 close here--->
		   <div class="col-sm-3">
          <div class="panel panel-default">
          <div class="panel-heading" style="background-color:red;color:white;">
		    <b>PMKVY</b>
          </div><!--panel heading close here--->
		  <div class="panel-body">
		  <center><b class="w3-jumbo">Rs.</b><b class="w3-xlarge"><sub>0/-</sub></b></center>
		  
		  <center><b>Feature's Of PMKVY Course<b> 
		  <h1>
	       <font color="red"> <span class="glyphicon glyphicon-hand-down"></span> </font>
	      </h1>
		  </center>
		  <li>
		  <font color="green"> <span class="glyphicon glyphicon-hand-right"></span> </font>
		  <b><font color="orange">Duration:</font><font color="indigo">3 Month</font></b></li>
		  <li>
		  <font color="green"> <span class="glyphicon glyphicon-hand-right"></span> </font>
		  <b><font color="orange">Fee:</font><font color="indigo">Free</font></b></li>
		  <font color="green"> <span class="glyphicon glyphicon-hand-right"></span> 
		  <b>For More Information <a href="pmkvy.php" title="HS-CIT Course">Click here</a></font>
		  </b>
		  </center>
		  <hr>
           </div><!--panel body close here--->
           </div><!--panel close here--->
           </div><!--col 2 close here--->
		    
			<div class="col-sm-3">
          <div class="panel panel-default">
          <div class="panel-heading" style="background-color:gold;color:white;">
		    <b>Computer Course</b>
          </div><!--panel heading close here--->
		  <div class="panel-body">
		  <center><b class="w3-jumbo">Rs.</b><b class="w3-xlarge"><sub>2000/-</sub></b><b></b></center>
		  <li class="list-group-item" style="color:red"><b>Duration:</b> 3 Month's</li>
           </div><!--panel body close here--->
		   </div><!--panel close here--->
		   <div class="row">
		          <div class="col-sm-12">
                  <div class="panel panel-default">
                  <div class="panel-heading" style="background-color:#212987;color:white;">
		          <b>Spoken English Course </b>
                  </div><!--panel heading close here--->
		          <div class="panel-body">
		          <center><b class="w3-jumbo">Rs.</b><b class="w3-xlarge"><sub>3500/-</sub></b><b></b></center>
				  <li class="list-group-item" style="color:red"><b>Duration:</b> 3 Month's</li>
		  		         
		         </div><!--panel body close here--->
                 </div><!--panel close here--->
                 </div><!--col 3 close here--->
		         </div><!---row close here--->
           </div><!--col 3 close here--->
		   
		   <div class="col-sm-3">
          <div class="panel panel-default">
          <div class="panel-heading" style="background-color:indigo;color:white;">
		    <b>TALLY ERP 9 WITH GST AND Bahi-Khata SOFTWARE</b>
          </div><!--panel heading close here--->
		  <div class="panel-body">
		  <center><b class="w3-jumbo">Rs.</b><b class="w3-xlarge"><sub>3350/-</sub></b></center>
		  <li class="list-group-item" style="color:red"><b>Duration:</b> 3 Month's</li>
           </div><!--panel body close here--->
		   
		          
		   
           </div><!--panel close here--->
           </div><!--col 3 close here--->
		              
		   <div class="col-sm-3">
          <div class="panel panel-default">
          <div class="panel-heading" style="background-color:#565;color:white;">
		    <b>Website Developement Course </b>
          </div><!--panel heading close here--->
		  <div class="panel-body">
		  <center><b class="w3-jumbo">Rs.</b><b class="w3-xlarge"><sub>500/-</sub></b><b>PM</b></center>
		  <li class="list-group-item" style="color:green"><b>Syllabus: Theory and Practical of HTML and Some Topics of CSS and JavaScript</b> 3 Month's</li>
           </div><!--panel body close here--->
           </div><!--panel close here--->
           </div><!--col 3 close here---> 
		   				  
		   <div class="col-sm-3">
          <div class="panel panel-default">
          <div class="panel-heading" style="background-color:#123;color:white;">
		    <b>Typing Course </b>
          </div><!--panel heading close here--->
		  <div class="panel-body">
		  <center><b class="w3-jumbo">Rs.</b><b class="w3-xlarge"><sub>700/-</sub></b><b>PM</b></center>
		  <li class="list-group-item" style="color:green"><b>Syllabus: English and Hindi Typing</li>
           </div><!--panel body close here--->
           </div><!--panel close here--->
           </div><!--col 3 close here--->
		   
		   <div class="col-sm-3">
          <div class="panel panel-default">
          <div class="panel-heading" style="background-color:#764;color:white;">
		    <b>Internet Course </b>
          </div><!--panel heading close here--->
		  <div class="panel-body">
		  <center><b class="w3-jumbo">Rs.</b><b class="w3-xlarge"><sub>700/-</sub></b><b>PM</b></center>
		  <li class="list-group-item" style="color:green"><b>Theory and Practical Knowledge of Internet</li>
           </div><!--panel body close here--->
           </div><!--panel close here--->
           </div><!--col 3 close here--->
		   
		   </div><!--row close here--->			   
</div><!---panel close here--->
</div><!--panel body close here--->
</div><!---panel close here--->
<!--------------------Follow us call here-------------->
<?php include 'follow.php';?>
<!--------------------footer call here----------------->
<?php include 'footer.php' ?>
</body>
</html>
<script src="alertify/js/alertify.js"></script>