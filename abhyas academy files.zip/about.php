<!DOCTYPE html>
<htmL>
<head>
<title>
About us - Abhyas Academy Ellenabad
</title>
  <meta name="author" content="skaran921,karan soni">
  <meta name="keyword" content="aaellenabad,Abhyas Academy Ellenabad,skaran921,About us">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<!------meta tag------>
<!----------------------Bootstrap Files--------------------------->
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="bootstrap/carousel.css" rel="stylesheet">
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/bootstrap.js"></script>
<!---------------------css Files------------------>
<link href="images/logo.jpg" rel="icon">
<link href="alertify/css/alertify.css" rel="stylesheet" id="alertifyCSS">
<link href="css/header.css" rel="stylesheet">
<link href="css/index.css" rel="stylesheet">
</head>
<body>
<!--------------------Header call here----------------->
<?php include 'header.php'; ?>
<div class="panel panel-info">
<div class="panel-heading">
<b>About us</b>
</div><!--panel heading close here--->
<div class="panel-body">
<b></b>
</div><!--panel body close here--->
<ul class="list-group"> 
  <div style="font-family:hindi;margin-left:20px;margin-right:20px;font-size:22px;color:indigo;text-align:left;" class="row">    
<div class="col-sm-12">    
 <li class="list-group-item">
<font color="red"><span class="glyphicon glyphicon-asterisk"></span></font>
vH;kl ,dsM+eh f’k{kk ds {ks= esa ,d ,slk f’k{k.k laLFkku gS ftldh LFkkiuk o"kZ vDrqcj 2016 es gwbZ Fkh tc geus bl f’k{k.k lLFkku fd LFkkiuk fd rc gekjk ,d gh y{; Fkk fd fo/kkFkhZ;ks dks vPNh f’k{kk iznku fd tkos rkfd oks vius Hkfo"; dks mPpoy cuk lds A gekjk lnSo ;gh iz;kl jgk gS fd fo/kkFkhZ;ks dks f’k{kk ds {ks= es fdlh izdkj fd deh eglql uk gks o mUgs vPNh xq.kork o LkLrh f’k{kk iznku fd tkos rkfd oks fo/kkFkhZ tks xjhc ifjokj ls vkrs iSls fd deh ds dkj.k i< ugh ikrs oks Hkh f’k{kk ls oafpr uk jgsa A
</li>

</div>
</div>
</ul>
<!---------------------------------------------------------first paragraph close here------------------------------------------------->


          <ul class="list-group"> 
                <div style="font-family:hindi;margin-left:20px;margin-right:20px;font-size:22px;color:indigo;"><!-------------------------feature------------------------->
<h3><u><font color="red"><span class="glyphicon glyphicon-hand-right"></span></font> lqfo/kk %&</u></h3>
                    <center><h1><font color="green"><span class="glyphicon glyphicon-hand-down"></span></font></h1></center>
          <li class="list-group-item"><font color="green"><span class="glyphicon glyphicon-arrow-right"></span></font> vH;kl ,dsMeh ds ikl ,d viuk cgqr cMk dSEil tgka ij vyx&vyx Dykl ds fy, vyx&vyx dejks fd lqfo/kk¼ F;ksjh o izSfDVdy½ gS  </li>
          <li class="list-group-item"><font color="green"><span class="glyphicon glyphicon-arrow-right"></span></font> iqjk dSEil okbZ&QkbZ ls ySal ¼tqMk½ gqvk gS gkbZ LihM MsVk ds lkFk baVjuSV fd lqfo/kk </li>
          <li class="list-group-item"><font color="green"><span class="glyphicon glyphicon-arrow-right"></span></font> dEi;qVj okyh 2 cMh ySc lqfo/kk lHkh dEi;qVjks es baVjuSV fd lqfo/kk rFkk 160thch gkMZ fMLd o 2 thch jSe vkSj baVy M;qy dkSj izkslslj ds lkFk mIkYc/k gS </li>
          <li class="list-group-item"><font color="green"><span class="glyphicon glyphicon-arrow-right"></span></font> dSEil esa ykbZczsjh fd lqfo/kk tgka ij fo/kkFkhZ;ksa dks f’k{kk ls lacf/kr lHkh fo"k; lkexzh ¼fdrkcs½ miYc/k gS </li> 
         <li class="list-group-item"><font color="green"><span class="glyphicon glyphicon-arrow-right"></span></font> dSEil esa ,d izkstsDVj fd lqfo/kk gS ftlds ek/;e ls fo/kkFkhZ;ks dks vkuykbZu Dykl yxkbZ tkrh</li>
         <li class="list-group-item"><font color="green"><span class="glyphicon glyphicon-arrow-right"></span></font> dSEil esa ,lh o dqyj fd lqfo/kk gS rkfd fo/kkFkhZ;ks dks i<kbZ djrs le; xehZ es fdlh izdkj fd dksbZ fnDdr uk gks A </li>
        <li class="list-group-item"><font color="green"><span class="glyphicon glyphicon-arrow-right"></span></font> vH;kl ,dsMeh bruh lqfo/kkvksa ls ifjiq.kZ ,syukckn es igyk ,d ,slk f’k{k.k laLFkku gS tgka ij bruh lqfo/kk,a miYc/k gS A </li>
        <li class="list-group-item"><font color="green"><span class="glyphicon glyphicon-arrow-right"></span></font> vH;kl ,dsMeh ds ikl vuqHkoh o ;ksX; f”kf{kr v/;kid gS ftuds ikl bl {ks= es dkQh  vuqHko gS tks cgwr le; ls bl {ks= es dk;Z dj jgsa gS fdlh Hkh fo/kkFkhZ dks f’k{kk ls lacf/kr dksbZ Hkh tkudkjh izkIr djuh gks rks oks gels ,d ckj vo”; feys rkfd lgh le; ij vkidks lgh tkudkjh fey lds A</li>
          <center style="color:red">vH;kl ,dsMeh ,syukckn </center>
          </div>
          </ul>


         
</div><!---panel close here--->
<div class="externel link" style="font-family:book antiqua;">
<!--------------------Follow us call here-------------->
<?php include 'follow.php';?>
<!--------------------footer call here----------------->
<?php include 'footer.php' ?>
</div>
</body>
<4/html>
<script src="alertify/js/alertify.js"></script>
<style>
@font-face {
    font-family: hindi;
    src: url(font/KRDEV044.TTF);
    font-weight:bold;
     
}
</style>