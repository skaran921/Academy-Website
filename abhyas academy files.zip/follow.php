<link href="css/follow.css" rel="stylesheet">
<link href="bootstrap-social/bootstrap-social.css" rel="stylesheet">
<link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
<div class="panel panel-warning">
   <div class="panel-heading">
      <b>Follow us</b>
   </div>
     <div class="panel-body" id="body">
	      <div class="row">
	      <div class="col-sm-12">
		  <center>
		    <a class="btn btn-social-icon btn-facebook" title="Facebook">
                   <span class="fa fa-facebook"></span>
           </a>
		    <a class="btn btn-social-icon btn-twitter" title="Twitter">
                   <span class="fa fa-twitter"></span>
           </a>
		    <a class="btn btn-social-icon btn-instagram" title="instagram">
                   <span class="fa fa-instagram"></span>
           </a>
		   <a class="btn btn-social-icon btn-google" title="Google+">
                   <span class="fa fa-google"></span>
           </a>
		    <a class="btn btn-social-icon btn-linkedin"title="Linkedin">
                   <span class="fa fa-linkedin"></span>
           </a>
		    <a class="btn btn-social-icon btn-flickr" title="Flickr">
                   <span class="fa fa-flickr"></span>
           </a>
		    <a class="btn btn-social-icon btn-pinterest" title="Pinterest">
                   <span class="fa fa-pinterest"></span>
           </a>
		    <a class="btn btn-social-icon btn-windows" title="Windows">
                   <span class="fa fa-windows"></span>
           </a>
		   </center>
		  </div>
		  </div>
	 </div>
</div>