<!DOCTYPE html>
<htmL>
<title>
About PMKVY Course
</title>
  <meta name="author" content="skaran921,karan soni">
  <meta name="keyword" content="aaellenabad,Abhyas Academy Ellenabad,skaran921,Add New Student">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<!------meta tag------>
<!----------------------Bootstrap Files--------------------------->
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="bootstrap/carousel.css" rel="stylesheet">
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/bootstrap.js"></script>
<!---------------------css Files------------------>
<link href="logo.jpg" rel="icon">
<link href="alertify/css/alertify.css" rel="stylesheet" id="alertifyCSS">
<link href="css/header.css" rel="stylesheet">
<link href="css/index.css" rel="stylesheet">
</head>
<body>
<!--------------------Header call here----------------->
<?php include 'header.php'; ?>
<input type="button" value="Dashboard" class="btn btn-danger" onclick="window.open('dashboard.php','_selef')">

<div class="panel panel-primary" style="margin-top:10px;">
<div class="panel-heading">
<b>About PMKVY Course</b>
</div><!--- panel heading close here--->
<div class="panel-body">

      <center>
	  <h3 style="color:orange">
	  <u>Welcome to PMKVY</u><br>
	  </h3>
	  </center>
	  <center>
	  <h1>
	  <font color="red"> <span class="glyphicon glyphicon-hand-down"></span> </font>
	  </h1>
	  </center>
	  

<p><b>
        Pradhan Mantri Kaushal Vikas Yojana (PMKVY) is the flagship scheme of the Ministry of Skill Development & Entrepreneurship (MSDE). 
		The objective of this Skill Certification Scheme is to enable a large number of Indian youth to take up industry-relevant skill training that will help them in securing a better livelihood.
		Individuals with prior learning experience or skill will also be assessed and certificate under Recognition of Prior Learning (RPL).
</b></p>
<hr>
<p>
<u>
<b style="color:orange;font-size:18px;">Skill India</b></u><b> is a campaign launched by Prime Minister Narendra Modi on 15 July 2015 which aim to train over 40 crore (400 million) people in India in 
different skill by 2022 . It include various initiatives of the government like “National Skill Development Mission”, “National Policy for skill Development and Entrepreneurship 2015” “Pradhan Mantri Kaushal Vikas Yojana (PMKVY) “ and the Skill Loan Scheme”.
</b>
</p>
<b><u style="color:indigo;font-size:18px;">COURSE Detail:- :-</u></b><br>
<ol style="font-weight:bold;font-family:arial;">
<li><font color="red"> <span class="glyphicon glyphicon-hand-right"></span> </font>SEWING MACHINE ( SELF EMPLOYED TAILOR ) </li>
<li><font color="red"> <span class="glyphicon glyphicon-hand-right"></span> </font>TELECOME ( CALL CENTER )</li>
</ol>
<b style="color:red"><span class="glyphicon glyphicon-asterisk"></span></b>
<b style="font-family:calbari;font-size:18px;color:slateblue">
</b>
<b style="color:green">
ONLINE ADMISSION FOR PMKVY FILL A BASIC ONLINE FORM LINK ARE PROVIDED ABOVE  RIGHT SIDE OF TOP MENU OR <a href="form.php" title="Apply Online For Admission">CLICK HERE.</a> 
</b>

</div><!--- Panel body here--->
</div><!--- Panel close here--->

<!--------------------Follow us call here-------------->
<?php include 'follow.php';?>
<!--------------------footer call here----------------->
<?php include 'footer.php' ?>
</body>
</html>
<script src="alertify/js/alertify.js"></script>